package ParkingSimulation;

//The ParkedCar is exactly at the parking time purchased.
public class Test5
{
	private ParkedCar car;
	private ParkingMeter pm;
	private PoliceOfficer police;
	
	public Test5(){
		car = new ParkedCar("BMW", "RAD 345T", "blue", 10);
		pm = new ParkingMeter(10);
		police = new PoliceOfficer("Johnson", "JHPO");
	}
	
	
	public void printTicket()
	{
		police.examineTicket(pm, car);
	}
}
