// This is Parking simulation main class
// @author John W Munyi
//On my honor, as a Carnegie-Mellon Rwanda student, I have neither given nor received unauthorized assistance on this work.

package ParkingSimulation;

public class TestParkingTicket
{

	public static void main(String[] args)
	{
		Test1 car1 = new Test1();
		car1.printTicket();
		System.out.println("===========================================================");
		Test2 car2 = new Test2();
		car2.printTicket();
		System.out.println("===========================================================");
		Test3 car3 = new Test3();
		car3.printTicket();
		System.out.println("===========================================================");
		Test4 car4 = new Test4();
		car4.printTicket();
		System.out.println("===========================================================");
		Test5 car5 = new Test5();
		car5.printTicket();
		System.out.println("===========================================================");
		Test6 car6 = new Test6();
		car6.printTicket();
		System.out.println("===========================================================");
		Test7 car7 = new Test7();
		car7.printTicket();
		System.out.println("===========================================================");
		Test8 car8 = new Test8();
		car8.printTicket();
		System.out.println("===========================================================");
	}
}
