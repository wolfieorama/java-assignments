// This is Parking meter class
// @author John W Munyi
//On my honor, as a Carnegie-Mellon Rwanda student, I have neither given nor received unauthorized assistance on this work.
package ParkingSimulation;


public class ParkingMeter
{
	double minutesPurchased;
	
	public ParkingMeter(double minutesPurchased)
	{
		setMinutesPurchased(minutesPurchased);
	}
	
	public void setMinutesPurchased(double minutesPurchased)
	{
		this.minutesPurchased = minutesPurchased;
	}
	
	double getMinutesPurchased()
	{
		return minutesPurchased;
	}
	
	public String toString()
	{
		return "the Minutes purchased are: " + minutesPurchased;
	}
}
